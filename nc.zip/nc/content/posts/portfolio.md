+++
title = 'some general updates'
date = 2024-11-19T13:17:13-05:00
draft = false
+++
this platform will be used more and more for portfolio updates (acedemic and otherwise)
check the PROJECTS TAB for more updates on that front, also planniing on trying to migrate this site to a new domain
and host it either locally or on aws.

-f
