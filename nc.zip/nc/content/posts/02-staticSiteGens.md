---
title: "02 StaticSiteGens"
date: 2024-09-29T15:36:12-04:00
slug: 2024-09-29-02-staticsitegens
type: posts
draft: false
categories:
  - default
tags:
  - default
---
Why is it that static site generators are so finnicky? I have spent more hours of my life trying to wrestle HUGO into working than I rightly should have
considering the fact that it is supposed to be a "Fast" and "simple" Generator. Themes are a pain to install when they have depepndencies, the themes page is poorly updated
and many themes just simply don't work. So I will go to the hugo themes website and add the theme that looks OK. Then I will copy the config over etc etc and then
the content I write Just won't show up. I mentioned it before in my other post, but I almost gave up this whole website thing; it seemed like too much of a hassle. 
I was banging my head against the keyboard (figurativley) and wishing I could be like other people. Because other people don't devote their free time to
creating blogs that nobody really sees. Normal people don't spend the precious hours of the weekend in GNU nano configuring the 20th static site generator of the day.
But at the end of the day, the programmer cycle of "I am a moron, I am a genius" is omnipresent. One day feels like a kick in the butt, you can't even
configure a "user-friendly" static site generator to work correctly. I used to have a vanilla HTML and CSS site (at this very address) but I read an article about
how hotlinking is bad for making you're website exist for years. (the article)[https://jeffhuang.com/designed_to_last/]
Anyway I decided to migrate my very very seizure inducing neocities page to be both more modern, more minimal, and more mindful the future.
So I guess the key takeaway is that despite how annoying static site generators are, at the end of the day most anything is easier than CSS and therefore
they are worth the struggle. 
