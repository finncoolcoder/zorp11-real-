---
title: "Hi there, this is Salinger theme."
description: "A clean, minimalistic, mobile-first, blazing-fast, powerfull theme for Hugo framework made with Tailwind and DaisyUI. Please consider starring this project on Github."
---
