echo "push.sh initialized"
echo "building site"
hugo
echo "pushing to neocities------press CTRL+C To exit"
neocities push /home/finn/website-stuff/nc/public/
