---
title: "."

# The description appaers in the front page and below the title in the single-page hero.
description: "..."

# If lastmod is present, it overwrite the date in the meta.
date: 2023-07-01
lastMod: 2023-07-01

slug: slug-of-the-page

# other settings
featured: True # if true, the article appears in the homepage (only if the site parameter showOnlyFeaturedPost is true)
draft: False
toc: False 
math: False # if true, katex libraries are loaded

# taxonomies terms (as defined in the hugo.toml file)
categories: [""]
tags: [""]
langs: [""]
tools: [""]

# link and link text of a website displayed in the single-page hero.
link: "http://www.example.com"
linkText: "Example link"
---
